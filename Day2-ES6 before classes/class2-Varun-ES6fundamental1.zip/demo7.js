const employee = {
    id: 1,
    firstName: 'Mark',
    lastName: 'Smith',
    status: false
}

const oldEmployee = {
    ...employee,
    status: true
}


console.log(employee)
console.log(oldEmployee)