let scores = [10, 20, 30, 40, 50];

// for (let i = 0; i < scores.length; i++) {
//   console.log(scores[i]);
// }

for(let score of scores){
    console.log(score)
}
