class Book{
    title;
    author;
    price;
}

const book1 = new Book();
book1.title = 'Title 1';
book1.author = 'Author 1';
book1.price = 100;