const numbers = [10, 20, 30, 40];

// let result = [];

// for (number of numbers) {
//   let value = number * 10;
//   result.push(value);
// }

// console.log(result);

let result =  numbers.map((number) => number * 10 )
console.log(result)
