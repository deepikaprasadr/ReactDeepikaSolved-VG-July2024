let a = 100;
console.log(a)
a = 200;
console.log(a);

// const b = 100;
// console.log(b)
// b = 200;
// console.log(b)

const employee = {
    firstName: 'mark',
    lastName: 'smith'
}
console.log(employee)

employee.firstName = 'John';
console.log(employee);

employee = new Object();

